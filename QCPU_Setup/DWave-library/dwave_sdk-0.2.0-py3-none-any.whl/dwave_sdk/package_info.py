__version__ = '0.2.0'
__author__ = 'D-Wave Systems Inc.'
__authoremail__ = 'tools@dwavesys.com'
__description__ = 'Software development kit for open source D-Wave tools'
