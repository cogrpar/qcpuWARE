__version__ = '0.3.1'
__author__ = 'D-Wave Systems Inc.'
__authoremail__ = 'acondello@dwavesys.com'
__description__ = 'dimod wrapper for the D-Wave Micro Client'
